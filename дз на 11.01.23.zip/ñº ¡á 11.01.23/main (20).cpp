/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <locale>
#include <iostream>
 
using namespace std;
 
int main() {
    std::locale::global(std::locale(""));
    const int m=16;
    int KP=0,KM=0,KZ=0;
    int P[16];          
    cout<<"Введите элементы массива (16 штук) "<<endl;
    for (int i=0;i<m;i++) {       //Записывание элементов в массив и подсчет полож.,отриц.,нулевых эл-ов.
        cin>>P[i];
      if (P[i]>0) KP++;
      else if (P[i]<0) KM++;
      else KZ++;
    }   
    for (int i=0;i<m;i++) {           //Вывод массива.
        cout<<P[i]<<" ";
    }
    cout<<endl;
    cout<<"Количество положительных элементов  = "<<KP<<endl;
    cout<<"Количество отрицательных элементов  = "<<KM<<endl;
    cout<<"Количество нулевых элементов  = "<<KZ<<endl;
 
    system("pause");
    return 0;
}
