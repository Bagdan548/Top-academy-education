/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
using namespace std;
const int SIZE = 10;
int SUMMA = 0;
 
int averege(int array[SIZE][SIZE])
{
    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j < SIZE; j++)
        {
            cout << array[i][j] << "\t";
            
            if (array[i][j] % 2 != 0)
            {
                SUMMA += array[i][j];
            }
        }
        cout << endl;
    }
    return SUMMA;
}
 
void main(){
    cout << " Array" << endl;
    int array[SIZE][SIZE];
    cout << array[SIZE][SIZE] << endl;
    cout << "Anerege = "<< averege(array);
}